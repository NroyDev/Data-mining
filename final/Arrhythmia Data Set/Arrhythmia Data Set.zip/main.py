from Classification import Cla
from PreProcess import pre,pre2,pre3,pre4
import numpy as np
from Kmeans import Kmeans_predict
from sklearn.cluster import KMeans

N = 100

# 沒有把 分類器分出來的資料 丟到
def my_kmeans_ver():
    
    # 分類
    train_data,train_ans,test_data,test_ans = pre3("train_data.csv","train_label.csv","test_data.csv","test_label.csv")
    acc_avg = 0
    for i in range(N):
        preds, unknown_idx = Cla(train_data,train_ans,test_data,test_ans)

        preds_temp = np.delete(preds, unknown_idx)
        ans_temp = np.delete(test_ans, unknown_idx)
        print("Classifier ACC (排除不確定之資料): ",np.sum(preds_temp==ans_temp)/len(ans_temp))
        print("Classifier ACC (加入不確定之資料): ",np.sum(preds==test_ans)/len(test_ans))

        # 分群
        if(unknown_idx.size>5):
            unknown_data = test_data[unknown_idx]
            # kmeans = KMeans(n_clusters=5,max_iter=1000)
            # kmeans.fit(unknown_data)
            # labels = kmeans.labels_
            labels = Kmeans_predict(5,unknown_data,1000)

            values, counts = np.unique(labels, return_counts=True)
            order = values[counts.argsort()[::-1]]
            used = []
            for i in order:
                values, counts = np.unique(test_ans[unknown_idx][labels==i], return_counts=True)
                maxidx = 0
                for j in range(values.size):
                    # if(values[maxidx]<=8 or (values[maxidx] in used) or counts[maxidx]<counts[j]):
                    #     maxidx = j
                    if(values[maxidx]<=8 or (values[maxidx] in used) or counts[maxidx]<counts[j]):
                        maxidx = j
                # maxidx = np.argmax(counts)
                labels[labels==i] = values[maxidx]
                used.append(values[maxidx])
            preds[unknown_idx] = labels

            # 最終結果
            print("最後(Classifier再Clustur後) ACC: ",np.sum(preds==test_ans)/len(test_ans))
            acc_avg += np.sum(preds==test_ans)/len(test_ans)
        else:
            print("ERROR 沒有不確定的")
        print("--------------------------------------------------------")
        print("預測\n",preds)
        print("答案\n",test_ans)

    acc_avg/=N
    print(acc_avg)


def sklearn_kmeans_ver():
    # 分類
    train_data,train_ans,test_data,test_ans = pre3("train_data.csv","train_label.csv","test_data.csv","test_label.csv")
    acc_avg = 0
    for i in range(N):
        preds, unknown_idx = Cla(train_data,train_ans,test_data,test_ans)

        preds_temp = np.delete(preds, unknown_idx)
        ans_temp = np.delete(test_ans, unknown_idx)
        print("Classifier ACC (排除不確定之資料): ",np.sum(preds_temp==ans_temp)/len(ans_temp))
        print("Classifier ACC (加入不確定之資料): ",np.sum(preds==test_ans)/len(test_ans))

        # unknown_idx = np.arange(test_ans.size)
        # 分群
        if(unknown_idx.size>5):
            unknown_data = test_data[unknown_idx]
            kmeans = KMeans(n_clusters=5,max_iter=1000)
            kmeans.fit(unknown_data)
            labels = kmeans.labels_

            values, counts = np.unique(labels, return_counts=True)
            order = values[counts.argsort()[::-1]]
            used = []
            for i in order:
                values, counts = np.unique(test_ans[unknown_idx][labels==i], return_counts=True)
                maxidx = 0
                for j in range(values.size):
                    if(values[maxidx]<=8 or (values[maxidx] in used) or counts[maxidx]<counts[j]):
                        maxidx = j
                # maxidx = np.argmax(counts)
                labels[labels==i] = values[maxidx]
                used.append(values[maxidx])
            preds[unknown_idx] = labels

            # 最終結果
            print("最後(Classifier再Clustur後) ACC: ",np.sum(preds==test_ans)/len(test_ans))
            acc_avg += np.sum(preds==test_ans)/len(test_ans)
        else:
            print("ERROR 沒有不確定的")
        print("--------------------------------------------------------")
        print("預測\n",preds)
        print("答案\n",test_ans)

    acc_avg/=N
    print(acc_avg)





if __name__== '__main__':
    my_kmeans_ver()
    